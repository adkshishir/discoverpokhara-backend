<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comment extends BaseModel
{
    use HasFactory;
    protected $fillable=[
        'content',
        'user_id',
        'post_id',
    ];

    function user(){
        return $this->belongsTo(User::class);
    }

    function post(){
        return $this->belongsTo(Post::class);
    }
}
